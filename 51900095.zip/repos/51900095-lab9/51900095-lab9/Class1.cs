﻿namespace _51900095_lab9
{
    public class Class1
    {

    }
}